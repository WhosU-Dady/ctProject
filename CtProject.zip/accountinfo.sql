/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 80013
Source Host           : localhost:3306
Source Database       : ctdb

Target Server Type    : MYSQL
Target Server Version : 80013
File Encoding         : 65001

Date: 2021-06-23 03:40:39
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `accountinfo`
-- ----------------------------
DROP TABLE IF EXISTS `accountinfo`;
CREATE TABLE `accountinfo` (
  `userName` varchar(20) NOT NULL,
  `money` int(11) NOT NULL,
  KEY `A_userName` (`userName`),
  CONSTRAINT `A_userName` FOREIGN KEY (`userName`) REFERENCES `userinfo` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of accountinfo
-- ----------------------------
INSERT INTO `accountinfo` VALUES ('root', '100');
INSERT INTO `accountinfo` VALUES ('sss', '0');
INSERT INTO `accountinfo` VALUES ('ddd', '0');
INSERT INTO `accountinfo` VALUES ('hello', '50');
INSERT INTO `accountinfo` VALUES ('eee', '100');
INSERT INTO `accountinfo` VALUES ('zzc', '79');

-- ----------------------------
-- Table structure for `chat`
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `sender` varchar(255) NOT NULL,
  `acceptor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date` datetime NOT NULL,
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of chat
-- ----------------------------
INSERT INTO `chat` VALUES ('csg', 'root', '2021-06-07 18:07:45', '你好啊');
INSERT INTO `chat` VALUES ('root', 'csg', '2021-06-11 01:38:26', '你吗的');

-- ----------------------------
-- Table structure for `favourite`
-- ----------------------------
DROP TABLE IF EXISTS `favourite`;
CREATE TABLE `favourite` (
  `userName` varchar(20) NOT NULL,
  `menuName` varchar(20) NOT NULL,
  KEY `F_userName` (`userName`),
  CONSTRAINT `F_userName` FOREIGN KEY (`userName`) REFERENCES `userinfo` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of favourite
-- ----------------------------
INSERT INTO `favourite` VALUES ('root', 'Food');
INSERT INTO `favourite` VALUES ('sss', 'Food');
INSERT INTO `favourite` VALUES ('ddd', 'Food');
INSERT INTO `favourite` VALUES ('hello', 'Food');
INSERT INTO `favourite` VALUES ('eee', 'Food');
INSERT INTO `favourite` VALUES ('eee', '野猪炒肉');
INSERT INTO `favourite` VALUES ('zzc', 'Food');
INSERT INTO `favourite` VALUES ('zzc', 'Food');
INSERT INTO `favourite` VALUES ('zzc', '烤鸡');

-- ----------------------------
-- Table structure for `menucomment`
-- ----------------------------
DROP TABLE IF EXISTS `menucomment`;
CREATE TABLE `menucomment` (
  `userName` varchar(20) NOT NULL,
  `menuName` varchar(20) NOT NULL,
  `commentContent` varchar(255) NOT NULL,
  `commentDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `M_userName` (`userName`),
  KEY `M_menuName` (`menuName`),
  CONSTRAINT `M_menuName` FOREIGN KEY (`menuName`) REFERENCES `menuinfo` (`menuname`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `M_userName` FOREIGN KEY (`userName`) REFERENCES `userinfo` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of menucomment
-- ----------------------------
INSERT INTO `menucomment` VALUES ('root', '烤鸡', 'wocao ', '2021-06-22 22:25:55');
INSERT INTO `menucomment` VALUES ('root', '烤鸡', 'nnn', '2021-06-22 22:27:40');
INSERT INTO `menucomment` VALUES ('root', 'Food', 'ccccscscs', '2021-06-22 22:28:37');
INSERT INTO `menucomment` VALUES ('root', 'Food', 'cccc', '2021-06-22 22:31:03');

-- ----------------------------
-- Table structure for `menuinfo`
-- ----------------------------
DROP TABLE IF EXISTS `menuinfo`;
CREATE TABLE `menuinfo` (
  `menuName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` int(11) NOT NULL,
  `menuType` varchar(255) NOT NULL,
  `intro` varchar(255) DEFAULT NULL,
  `level` int(11) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `saleNum` int(11) NOT NULL,
  PRIMARY KEY (`menuName`),
  KEY `menuName` (`menuName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of menuinfo
-- ----------------------------
INSERT INTO `menuinfo` VALUES ('Food', '99', '标签', '我是食物标签，请勿拍下！', '5', '1.jpg', '20');
INSERT INTO `menuinfo` VALUES ('可口可乐', '5', '饮料', '气泡饮料，解渴必备。', '3', '18.jpg', '87');
INSERT INTO `menuinfo` VALUES ('多肉柚子', '18', '饮料', '满杯的柚子，口感非常地好。', '5', '17.jpg', '99');
INSERT INTO `menuinfo` VALUES ('宫爆鸡丁', '58', '菜品', '宫保鸡丁的简介及特色 宫保鸡丁，四川传统名菜。由鸡丁、干辣椒、花生米等炒制而成。', '4', '8.jpg', '60');
INSERT INTO `menuinfo` VALUES ('摆盘冬瓜', '45', '菜品', '冬瓜有降火的效果，有利于身体健康', '3', '11.jpg', '20');
INSERT INTO `menuinfo` VALUES ('木耳炒丝瓜', '55', '菜品', '口感好，多人推荐。木耳加丝瓜，好吃又健康。', '3', '10.jpg', '16');
INSERT INTO `menuinfo` VALUES ('烤鸡', '50', '菜品', '我是烤鸡', '4', '1.jpg', '20');
INSERT INTO `menuinfo` VALUES ('爆炒毛豆', '30', '菜品', '口感好，微辣。有助于饭前开胃', '3', '12.jpg', '22');
INSERT INTO `menuinfo` VALUES ('猪肚鸡', '99', '菜品', '好吃不腻，肉质鲜美', '5', '4.jpg', '13');
INSERT INTO `menuinfo` VALUES ('生菜', '30', '菜品', '多吃生菜，身体好。补充充分的维生素', '2', '13.jpg', '55');
INSERT INTO `menuinfo` VALUES ('白灼青菜', '38', '菜品', '青菜含有丰富的维生素', '3', '9.jpg', '13');
INSERT INTO `menuinfo` VALUES ('糖醋排骨', '100', '菜品', '糖醋排骨是糖醋味型中具有代表性的一道大众喜爱的特色传统名菜。它选用新鲜猪子排作主料，肉质鲜嫩，成菜色泽红亮油润', '5', '7.jpg', '12');
INSERT INTO `menuinfo` VALUES ('红烧鱼', '98', '菜品', '红烧鱼是用鲳鱼制作的一道闽菜菜品。鱼不仅味道鲜美，而且营养价值极高。其蛋白质含量为猪肉的2倍，且属于优质蛋白，人体吸收率高。', '4', '6.jpg', '45');
INSERT INTO `menuinfo` VALUES ('红牛', '8', '饮料', '功能维生素饮料，入口纯正', '3', '15.jpg', '90');
INSERT INTO `menuinfo` VALUES ('芬达', '5', '饮料', '气泡饮料，口感好', '3', '14.jpg', '88');
INSERT INTO `menuinfo` VALUES ('蒜香龙虾', '1399', '菜品', '融入了蒜末的味道，使龙虾的口感提升了，龙虾肉质鲜美', '5', '5.jpg', '22');
INSERT INTO `menuinfo` VALUES ('蜂蜜百香果', '15', '饮料', '用蜂蜜和百香果特制而成，混会起来口感特别。', '4', '16.jpg', '88');
INSERT INTO `menuinfo` VALUES ('香辣烤鸡', '88', '菜品', '铁板的牛肉', '4', '2.jpg', '21');

-- ----------------------------
-- Table structure for `shopping`
-- ----------------------------
DROP TABLE IF EXISTS `shopping`;
CREATE TABLE `shopping` (
  `userName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Menus` varchar(255) NOT NULL,
  `shoppingSum` int(11) NOT NULL,
  `shoppingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `S_userName` (`userName`),
  CONSTRAINT `S_userName` FOREIGN KEY (`userName`) REFERENCES `userinfo` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of shopping
-- ----------------------------
INSERT INTO `shopping` VALUES ('sss', 'null', '0', '2021-06-22 10:36:11');
INSERT INTO `shopping` VALUES ('ddd', 'null', '0', '2021-06-22 10:44:48');
INSERT INTO `shopping` VALUES ('hello', 'null', '0', '2021-06-22 10:48:29');
INSERT INTO `shopping` VALUES ('hello', '烤鸡*1', '50', '2021-06-22 10:53:01');
INSERT INTO `shopping` VALUES ('eee', 'null', '0', '2021-06-22 21:39:23');
INSERT INTO `shopping` VALUES ('zzc', 'null', '0', '2021-06-22 23:10:10');
INSERT INTO `shopping` VALUES ('zzc', 'Food*2,烤鸡*1,', '248', '2021-06-22 23:11:48');
INSERT INTO `shopping` VALUES ('zzc', '宫爆鸡丁*1,', '58', '2021-06-23 02:51:10');
INSERT INTO `shopping` VALUES ('zzc', '芬达*3,糖醋排骨*1,', '115', '2021-06-23 02:56:03');

-- ----------------------------
-- Table structure for `userinfo`
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `userName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(20) NOT NULL,
  `secQuestion` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `secAnswer` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  PRIMARY KEY (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES ('ddd', '111111', '11', '11', '11@qq.com');
INSERT INTO `userinfo` VALUES ('eee', '111111', 'eee', 'eee', 'eee@qq.com');
INSERT INTO `userinfo` VALUES ('hello', '111111', 'hh', 'hh', 'hh@qq.com');
INSERT INTO `userinfo` VALUES ('root', '111111', '111', '111', 'root@qq.com');
INSERT INTO `userinfo` VALUES ('sss', '111111', 'ccc', '111', '@qq.com');
INSERT INTO `userinfo` VALUES ('zzc', '123456', 'ccc', 'ccc', 'ccc@qq.com');
DELIMITER ;;
CREATE TRIGGER `AddAccount_userName` AFTER INSERT ON `userinfo` FOR EACH ROW begin
insert into Accountinfo (userName,money) values(new.userName,0);
end
;;
DELIMITER ;
DELIMITER ;;
CREATE TRIGGER `AddFavourite_userName` AFTER INSERT ON `userinfo` FOR EACH ROW begin
insert into favourite(userName,MenuName) values(new.userName,'Food');
end
;;
DELIMITER ;
DELIMITER ;;
CREATE TRIGGER `AddShopping_userName` AFTER INSERT ON `userinfo` FOR EACH ROW begin
insert into Shopping (userName,Menus,shoppingSum) values(new.userName,'null',0);
end
;;
DELIMITER ;
