function $(id) {
	return document.getElementById(id.replace('#',''));
}

function checkRecharge(){
    var userName = $("#userName");
    var money = $("#money");
    var num = /^[1-9]\d*$/;
    
    	if (userName.value.length == 0) {
    		alert("用户名不能为空！");
    		return false;
    	}
    	if (money.value.length == 0) {
    		alert("充值金额不能为空！");
    		return false;
    	}
    	if (money.value ==0) {
    		alert("充值金额不能为0！");
    		return false;
    	}    	
        if (!num.test(money.value)) {
            alert("充值金额填写正整数！");
            return false;
        }
        var msg = "请点击确认充值！";
        if (confirm(msg)==true){ 
        	 return true; 
        	}else{ 
        	 return false; 
        	}
	    
}
