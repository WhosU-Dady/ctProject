function $(id) {
	return document.getElementById(id.replace('#',''));
}

function checkFindPassword(){
	var email = $("#email");
	var userName = $("#userName");
	var secQuestion = $("#secQuestion");
	var secAnswer = $("#secAnswer");
	var password=$("#password");
	var repassword=$("#repassword");
	var email_reg = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
	
	if (userName.value.length == 0) {
		alert("用户名不能为空！");
		return false;
	}
	if (email.value.length == 0) {
		alert("邮箱不能为空！");
		return false;
	}
	if (!email_reg.test(email.value)) {
		alert("邮箱格式错误！");
		return false;
	}
	if (secQuestion.value.length == 0) {
		alert("密保不能为空！");
		return false;
	}
	if (secAnswer.value.length == 0) {
		alert("密保答案不能为空！");
		return false;
	}
	if (password.value.length <6) {
		alert("密码需要大于六位！");
		return false;
	}
	if (password.value != repassword.value) {
		alert("两次密码输入不一致，请重新输入！");
		return false;
	}
	return confirm("请点击确认修改密码！");
}

function check() {
	var username = document.getElementById("userName");
	var password = document.getElementById("password");

	if (username.value.length == 0) {
		alert("用户名不能为空！");
		return false;
	}
	if (password.value.length == 0) {
		alert("密码不能为空！");
		return false;
	}

	localStorage.setItem("menuinfo", "");

	return true;
}

function Validate(){
	var email = $("#email");
	var userName = $("#userName");
	var password = $("#password");
	var secQuestion = $("#secQuestion");
	var secAnswer = $("#secAnswer");
	var email_reg = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;

	if (userName.value.length == 0) {
		alert("用户名不能为空！");
		return false;
	}
	if (password.value.length == 0) {
		alert("密码不能为空！");
		return false;
	} else if (password.value.length < 6) {
		alert("密码不能小于6位！");
		return false;
	}
	if (secQuestion.value.length == 0) {
		alert("密保不能为空！");
		return false;
	}
	if (secAnswer.value.length == 0) {
		alert("密保答案不能为空！");
		return false;
	}
	if (!email_reg.test(email.value)) {
		alert("邮箱格式错误！");
		return false;
	}
	if (email.value.length == 0) {
		alert("邮箱不能为空！");
		return false;
	}
	return confirm("请点击确定完成注册！");
}

function deleteUsers(userName){
	if(confirm("确认删除该用户吗?")) {
		location.href = url+"/deleteByUserName?userName="+userName;
	}
}

function update() {
	
	if ($('#search-input').value.length == 0) {
		
		var list = document.querySelectorAll("tr");
		console.log(list)
		for (var i = list.length - 1; i > 0; --i) {
			list[i].style.display = "";
		}
	}
}

function search() {
	var list = document.querySelectorAll("tr");
	var searchtext = $('#search-input').value;
	for (var i = list.length - 1; i > 0; --i) {
		if (list[i].querySelectorAll("td")[0].innerHTML.indexOf(searchtext) == -1) {
			list[i].style.display = "none";
		} else {
			list[i].style.display = "";
		}
	}
}