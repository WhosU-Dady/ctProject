window.onload = function() {
    var menuName_list = document.querySelectorAll(".menuName-item");
    for (var i = 0; i < menuName_list.length; ++i) {
        menuName_list[i].href += btoa(encodeURIComponent(menuName_list[i].innerHTML));
        var span = document.createElement("span");
        span.innerHTML = (i+1);
        menuName_list[i].parentNode.insertBefore(span, menuName_list[i]);
    }

	labels_list = labels_list.split(",");
	const data = {
		// x 轴信息
		labels: labels_list,
		// 数据信息
		datasets: [
			{
				// 该线数据的名称和类型
				name: "消费值",
				// 具体数据
				values: value_list
			}
		]
	};

	const chart1 = new frappe.Chart("#chart", {
		// 数据
		data: data,
		// 图表类型 'axis-mixed' or 'line', 'pie', 'bar', 'percentage'
		type: 'line',
		// 高度
		height: 350,
		// 每一条线的颜色
		colors: ['#7cd6fd']
	});
}