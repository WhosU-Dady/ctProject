function $(id) {
	return document.getElementById(id.replace('#',''));
}
function update() {
	if ($('#search-input').value.length == 0) {
		var list = document.querySelectorAll(".item");
		for (var i = list.length - 1; i >= 0; --i) {
			list[i].style.display = "";
		}
	}
}

function search() {
	var list = document.querySelectorAll(".item");
	var searchtext = $('#search-input').value;
	for (var i = list.length - 1; i >= 0; --i) {
		if (list[i].querySelectorAll("h5")[0].innerHTML.indexOf(searchtext) == -1) {
			list[i].style.display = "none";
		} else {
			list[i].style.display = "";
		}
	}
}

Storage.prototype.getObject = function(key) {
    var ret = this.getItem(key);
    return ret ? JSON.parse(ret) : null;
}

Storage.prototype.setObject = function(key, json) {
    return this.setItem(key, JSON.stringify(json));
}

window.addEventListener("load", function() {
	var itemList = document.querySelectorAll(".item");
	var delList = document.querySelectorAll(".del-a");
	var menuinfo = localStorage.getObject("menuinfo");

	for (var i = 0; i < itemList.length; ++i) {
		if (menuinfo) {
			for (var j = 0; j < menuinfo.length; ++j) {
				if (menuinfo[j].name == itemList[i].querySelector("h5").innerHTML) {
					itemList[i].querySelector("span").innerHTML = menuinfo[j].number;
					break;
				}
			}
		}

		itemList[i].menuName = itemList[i].querySelector("h5").innerHTML;
		itemList[i].onclick = function() {
			localStorage.setItem("toMenu", this.menuName);
			window.location.href = url + "/toMenu?menuName=" + btoa(encodeURIComponent(this.menuName));
		}

		if (delList.length > 0) {
			delList[i].menuName = itemList[i].menuName;
			delList[i].onclick = function(e) {
				e.stopPropagation();
				if (confirm("是否删除该菜品？")) {
					window.location.href = url + "/DeleteMenu?menuName=" + btoa(encodeURIComponent(this.menuName));
				}
			}
		}

		itemList[i].querySelector(".sub").name = itemList[i].querySelector("h5").innerHTML;
		itemList[i].querySelector(".sub").number = itemList[i].querySelector("span");
		itemList[i].querySelector(".sub").price = itemList[i].querySelector("label");
		itemList[i].querySelector(".sub").img = itemList[i].querySelector("img").src;
		itemList[i].querySelector(".sub").onclick = function(e) {
			e.stopPropagation();
			var json = localStorage.getObject("menuinfo");
			var founded = false;
			if (!json) {
				json = [];
			}
			for (var j = 0; j < json.length; ++j) {
				if (json[j].name == this.name) {
					if (json[j].number == 0) {
						return;
					}
					json[j].number = parseInt(json[j].number)-1;
					this.number.innerHTML = json[j].number;
					founded = true;
					break;
				}
			}
			if (!founded) {
				json.push({
					name: this.name,
					price: this.price,
					img: this.img,
					number: 0
				})
				this.number.innerHTML = 0;
			}
			localStorage.setObject("menuinfo", json);
		}

		itemList[i].querySelector(".add").name = itemList[i].querySelector("h5").innerHTML;
		itemList[i].querySelector(".add").number = itemList[i].querySelector("span");
		itemList[i].querySelector(".add").price = itemList[i].querySelector("label").innerHTML;
		itemList[i].querySelector(".add").img = itemList[i].querySelector("img").src;
		itemList[i].querySelector(".add").onclick = function(e) {
			e.stopPropagation();
			var json = localStorage.getObject("menuinfo");
			var founded = false;
			if (!json) {
				json = [];
			}
			for (var j = 0; j < json.length; ++j) {
				if (json[j].name == this.name) {
					json[j].number = parseInt(json[j].number)+1;
					this.number.innerHTML = json[j].number;
					founded = true;
					break;
				}
			}
			if (!founded) {
				json.push({
					name: this.name,
					price: this.price,
					img: this.img,
					number: 1
				})
				this.number.innerHTML = 1;
			}
			localStorage.setObject("menuinfo", json);
		}
	}

	var floatBox = document.querySelector('#float-box');
    var floatTrun = 0;
    var floatArray = ["0", "-100%", "-200%", "-300%"];
    function ShowNext() {
        floatTrun = floatTrun == 3 ? 0 : floatTrun + 1;
        floatBox.style.marginLeft = floatArray[floatTrun];
    }
    var Timer = setInterval(ShowNext, 5000);

    var arrowBtnL = document.querySelectorAll('.arrow')[0];
    var arrowBtnR = document.querySelectorAll('.arrow')[1];
    arrowBtnL.onclick = function() {
        clearInterval(Timer);
        floatTrun = floatTrun == 0 ? 3 : floatTrun - 1;
        floatBox.style.marginLeft = floatArray[floatTrun];
        Timer = setInterval(ShowNext, 5000);
    }

    arrowBtnR.onclick = function() {
        clearInterval(Timer);
        ShowNext();
        Timer = setInterval(ShowNext, 5000);
    }
    
    
});