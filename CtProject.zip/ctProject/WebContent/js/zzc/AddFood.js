function $(id) {
	return document.getElementById(id.replace('#',''));
}

function checkAddFood(){
    var menuName = $("#menuName");
    var price = $("#price");
    var menuType = $("#menuType");
    var level=$("#level");
    var picture=$("#picture");
    var saleNum=$("#saleNum");
    var num = /^[0-9].*$/;
    var levelnum=/^[1-5]$/;
    
    
    	if (menuName.value.length == 0) {
    		alert("菜品名不能为空！");
    		return false;
    	}
    	if (price.value.length == 0) {
    		alert("价格不能为空！");
    		return false;
    	}

        if (menuType.value.length == 0) {
            alert("菜品类型不能为空！");
            return false;
        }

        if (level.value.length == 0) {
            alert("大众评价不能为空！");
            return false;
        }
        if (picture.value.length == 0) {
            alert("图片不能为空！");
            return false;
        }
        if (saleNum.value.length == 0) {
            alert("销售数量不能为空！");
            return false;
        }
        if (!num.test(price.value) || !num.test(level.value) || !num.test(saleNum.value)) {
            alert("价格、大众评价、销售数量请填写数字！");
            return false;
        }
        if (!levelnum.test(level.value)) {
            alert("大众评分请填写0-5之间的数字");
            return false;
        }
        var msg = "请点击确认增加菜品！";
        if (confirm(msg)==true){ 
        	 return true; 
        	}else{ 
        	 return false; 
        	}
	    
}