Storage.prototype.getObject = function(key) {
    var ret = this.getItem(key);
    return ret ? JSON.parse(ret) : null;
}

Storage.prototype.setObject = function(key, json) {
    return this.setItem(key, JSON.stringify(json));
}


function handin_comment() {
	window.location.href =
		url+"/AddComment?userName="+localStorage.getItem("userName")
		+"&menuName="+btoa(encodeURIComponent(menuName))
		+"&commentContent="+btoa(encodeURIComponent(document.querySelector("#comment-box").value));
}

window.addEventListener("load", function() {
	var item = document.querySelector(".item-opera");
	var menuinfo = localStorage.getObject("menuinfo");

	if (menuinfo) {
		for (var j = 0; j < menuinfo.length; ++j) {
			if (menuinfo[j].name == menuName) {
				item.querySelector("span").innerHTML = menuinfo[j].number;
				break;
			}
		}
	}

	var startlist = document.querySelectorAll(".stars ul li");
	for (var i = 0; i < level; ++i) {
		startlist[i].setAttribute("stars", "null");
	}

	document.querySelector("#add-favourite").href +=
		"?userName="+localStorage.getItem("userName")+"&menuName="+btoa(encodeURIComponent(menuName))

	item.querySelector(".sub").name = menuName;
	item.querySelector(".sub").number = item.querySelector("span");
	item.querySelector(".sub").onclick = function(e) {
		e.stopPropagation();
		var json = localStorage.getObject("menuinfo");
		var founded = false;
		if (!json) {
			json = [];
		}
		for (var j = 0; j < json.length; ++j) {
			if (json[j].name == this.name) {
				if (json[j].number == 0) {
					return;
				}
				json[j].number = parseInt(json[j].number)-1;
				this.number.innerHTML = json[j].number;
				founded = true;
				break;
			}
		}
		if (!founded) {
			json.push({
				name: this.name,
				number: 0
			})
			this.number.innerHTML = 0;
		}
		localStorage.setObject("menuinfo", json);
	}

	item.querySelector(".add").name = menuName;
	item.querySelector(".add").number = item.querySelector("span");
	item.querySelector(".add").onclick = function(e) {
		e.stopPropagation();
		var json = localStorage.getObject("menuinfo");
		var founded = false;
		if (!json) {
			json = [];
		}
		for (var j = 0; j < json.length; ++j) {
			if (json[j].name == this.name) {
				json[j].number = parseInt(json[j].number)+1;
				this.number.innerHTML = json[j].number;
				founded = true;
				break;
			}
		}
		if (!founded) {
			json.push({
				name: this.name,
				number: 1
			})
			this.number.innerHTML = 1;
		}
		localStorage.setObject("menuinfo", json);
	}
});