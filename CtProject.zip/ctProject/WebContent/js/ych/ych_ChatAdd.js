	var message_list = null;
	// TODO 获取用户名
	var username = 'c1';//null;
	var input_area = null;
	var send_iframe = null, receive_iframe = null;
	var get_message = 0;
	
	window.onload = function() {
		document.querySelector('.chat-main').style.height = document.documentElement.clientHeight + "px";
		message_list = document.querySelector('.message-list');
		input_area = document.querySelector('.input-area');
		
		if (window.frames.length != parent.frames.length &&
				window.parent.document.getElementById('Chat-Main-id') != null)
		{
			document.body.innerHTML =
				'<form action="chatDo" method="post">'+
					'<input type="text" name="sender"/>'+
					'<input type="text" name="acceptor"/>'+
					'<input type="text" name="content"/>'+
					'<input type="text" name="date"/>'+
					'<input type="submit"/>'+
				'</form>';
		} else {
			localStorage.removeItem("last-get-message-time");
			localStorage.setItem("username", username);
			
			send_iframe = document.createElement("iframe");
			send_iframe.setAttribute("style", "display: none");
			send_iframe.setAttribute("id", "send-iframe-id");
			send_iframe.setAttribute("src", "../ychdemo");
			document.body.appendChild(send_iframe);
			
			receive_iframe = document.createElement("iframe");
			receive_iframe.setAttribute("style", "display: none");
			receive_iframe.setAttribute("id", "receive-iframe-id");
			receive_iframe.setAttribute("src", "chatOnlyDo");
			document.body.appendChild(receive_iframe);
			
			setInterval(function() {
				receive_iframe.contentWindow.location.reload();
			}, 500);
		}
	}
	
	function getTimestamp(date) {
		if (date) {
			return Math.floor(Date.parse(new Date(date)));
		} else {
			return Math.floor(Date.parse(new Date()));
		}
	}
	
	function sendTextMessage() {
		// 移除字符串所有空格进行判空
		if (input_area.value.replace(" ", "").length == 0) {
			alert("不能发送空信息！");
			return;
		}
		
		// 2021-05-18 00:00:00
		var nowDate = new Date();
		var Y = nowDate.getFullYear();
		var MM = nowDate.getMonth()+1;
		var DD = nowDate.getDate();
		var hh = nowDate.getHours();
		var mm = nowDate.getMinutes();
		var ss = nowDate.getSeconds();
		var action_input_list = send_iframe.contentWindow.document.querySelectorAll('input');
		
		action_input_list[0].value = username;
		action_input_list[1].value = "root";
		action_input_list[2].value = input_area.value;
		action_input_list[3].value = Y+"-"+(MM>9?MM:"0"+MM)+"-"+(DD>9?DD:"0"+DD)+" "+(hh>9?hh:"0"+hh)+":"+(mm>9?mm:"0"+mm)+":"+(ss>9?ss:"0"+ss);
		action_input_list[4].click();
		
		addMessageDOM(input_area.value, true, getTimestamp());
	}
	
	function addMessageDOM(content, isSender, date) {
		var new_message = document.createElement("li");
		var last_get_message_date = localStorage.getItem("last-get-message-time");
		
		function addDataItem(data) {
			var chat_time = document.createElement("li");
			chat_time.setAttribute("class", "message-item-time");
			
			date = new Date(date);
			var m = date.getMinutes();
			chat_time.innerHTML = date.getHours()+':'+(m > 9 ? m : '0'+m);
			message_list.appendChild(chat_time);
		}

		if (last_get_message_date) {
			if (date - last_get_message_date > 300*1000) {
				localStorage.setItem("last-get-message-time", date);
				addDataItem(date);
			}
		} else {
			localStorage.setItem("last-get-message-time", date);
			addDataItem(date);
		}
		
		if (isSender) {
			new_message.setAttribute("class", "message-item-sender");
			new_message.innerHTML =
				'<div class="message-item-sender-text">'+content+'</div>'+
				'<a href="https://www.baidu.com/" title="进入个人中心">'+
					'<div class="message-item-sender-img">'+(username != null ? username[0] : '?')+'</div>'+
				'</a>';
			input_area.value = "";
		} else {
			new_message.setAttribute("class", "message-item-receiver");
			new_message.innerHTML =
				'<div class="message-item-receiver-img"></div>'+
				'<div class="message-item-receiver-text">'+content+'</div>';
		}
		message_list.appendChild(new_message);
		message_list.scrollTop = message_list.scrollHeight;
		get_message++;
	}

