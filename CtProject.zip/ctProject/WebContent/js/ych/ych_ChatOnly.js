	window.onload = function() {
			
		var username = localStorage.getItem("username");
		if (window.frames.length != parent.frames.length)
		{
			var tr_list = document.querySelectorAll("tr");
			var len = tr_list.length;
			for (var i = window.parent.get_message; i < len; ++i) {
				var td_list = tr_list[i].querySelectorAll("td");
				window.parent.addMessageDOM(
						td_list[0].innerHTML,
						td_list[2].innerHTML == username,
						window.parent.getTimestamp(td_list[1].innerHTML));
			}
		}
	}
