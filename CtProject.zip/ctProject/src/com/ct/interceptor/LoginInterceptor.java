package com.ct.interceptor;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginInterceptor implements HandlerInterceptor {

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();
        
        System.out.println(request.getRequestURI());

        if(request.getRequestURI().contains("Login") || request.getRequestURI().contains("login") || request.getRequestURI().contains("Forget")){
            System.out.println(request.getRequestURI());

            return true;
        }
        if(request.getRequestURI().contains("Register") || request.getRequestURI().contains("register")||request.getRequestURI().contains("Index") ){
            System.out.println(request.getRequestURI());

            return true;
        }


        if(session.getAttribute("user") != null){
        	if(request.getRequestURI().contains("userAll")) {
                request.getRequestDispatcher("/WEB-INF/nian/Login.jsp").forward(request, response);
        		return false;
        	} else {
        		return true;
        	}
        }
        
        if(session.getAttribute("root") != null){
        	return true;
        }

        request.getRequestDispatcher("/WEB-INF/nian/Login.jsp").forward(request, response);
        return false;
    }
}