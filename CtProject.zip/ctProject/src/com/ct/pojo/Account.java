package com.ct.pojo;

public class Account {
	private String userName;
	private int money=5;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(String userName, int money) {
		super();
		this.userName = userName;
		this.money = money;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	@Override
	public String toString() {
		return "Account [userName=" + userName + ", money=" + money + "]";
	}

	public void a(int money) {
		
		System.out.println(this);
	}	
	public static void main(String args[]) {
		Account a= new Account();
		a.a(3);
	}

}
