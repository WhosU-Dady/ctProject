package com.ct.pojo;

public class MenuComment {
	private String userName;
	private String menuName;
	private String commentContent;
	private String commentDate;
	public MenuComment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MenuComment(String userName, String menuName, String commentContent, String commentDate) {
		super();
		this.userName = userName;
		this.menuName = menuName;
		this.commentContent = commentContent;
		this.commentDate = commentDate;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getCommentContent() {
		return commentContent;
	}
	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}
	public String getCommentDate() {
		return commentDate;
	}
	public void setCommentDate(String commentDate) {
		this.commentDate = commentDate;
	}
	@Override
	public String toString() {
		return "MenuComment [userName=" + userName + ", menuName=" + menuName + ", commentContent=" + commentContent
				+ ", commentDate=" + commentDate + "]";
	}
	
	
	

}
