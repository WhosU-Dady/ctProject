package com.ct.pojo;

public class Shopping {
	private String userName;
	private String menus;
	private int shoppingSum;
	private String shoppingDate;

	public Shopping() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Shopping(String userName, int shoppingSum, String menus, String shoppingDate) {
		super();
		this.userName = userName;
		this.shoppingSum = shoppingSum;
		this.menus = menus;
		this.shoppingDate = shoppingDate;

	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getShoppingSum() {
		return shoppingSum;
	}
	public void setShoppingSum(int shoppingSum) {
		this.shoppingSum = shoppingSum;
	}
	public String getMenus() {
		return menus;
	}
	public void setMenus(String menus) {
		this.menus = menus;
	}
	public String getShoppingDate() {
		return shoppingDate;
	}
	public void setShoppingDate(String shoppingDate) {
		this.shoppingDate = shoppingDate;
	}

	@Override
	public String toString() {
		return "Shopping [userName=" + userName + ", shoppingSum=" + shoppingSum + ", menus=" + menus
				+ ", shoppingDate=" + shoppingDate + "]";
	}


	
	

}
