package com.ct.pojo;

public class Favourite {
	private String userName;
	private String menuName;
	public Favourite() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Favourite(String userName, String menuName) {
		super();
		this.userName = userName;
		this.menuName = menuName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	@Override
	public String toString() {
		return "Favourite [userName=" + userName + ", menuName=" + menuName + "]";
	}
	
	

}
