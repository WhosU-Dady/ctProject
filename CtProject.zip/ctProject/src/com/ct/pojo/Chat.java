package com.ct.pojo;

public class Chat {
	private String sender;
	private String acceptor;
	private String date;
	private String content;
	
	public Chat() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Chat(String sender, String acceptor, String date, String content) {
		super();
		this.sender = sender;
		this.acceptor = acceptor;
		this.date = date;
		this.content = content;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getAcceptor() {
		return acceptor;
	}
	public void setAcceptor(String acceptor) {
		this.acceptor = acceptor;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "Chat [sender=" + sender + ", acceptor=" + acceptor + ", date=" + date + ", content=" + content + "]";
	}
	
	

}
