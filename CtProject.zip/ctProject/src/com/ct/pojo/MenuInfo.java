package com.ct.pojo;

public class MenuInfo {
	private String menuName;
	private int price;
	private String menuType;
	private String intro;
	private int level;
	private String picture;
	private int saleNum;
	
	
	public MenuInfo() {
		super();
		// TODO Auto-generated constructor stub
	}


	public MenuInfo(String menuName, int price, String menuType, String intro, int level, String picture, int saleNum) {
		super();
		this.menuName = menuName;
		this.price = price;
		this.menuType = menuType;
		this.intro = intro;
		this.level = level;
		this.picture = picture;
		this.saleNum = saleNum;
	}


	public String getMenuName() {
		return menuName;
	}


	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public String getMenuType() {
		return menuType;
	}


	public void setMenuType(String menuType) {
		this.menuType = menuType;
	}


	public String getIntro() {
		return intro;
	}


	public void setIntro(String intro) {
		this.intro = intro;
	}


	public int getLevel() {
		return level;
	}


	public void setLevel(int level) {
		this.level = level;
	}


	public String getPicture() {
		return picture;
	}


	public void setPicture(String picture) {
		this.picture = picture;
	}


	public int getSaleNum() {
		return saleNum;
	}


	public void setSaleNum(int saleNum) {
		this.saleNum = saleNum;
	}
	
	@Override
	public String toString() {
		return "MenuInfo [menuName=" + menuName + ", price=" + price + ", menuType=" + menuType + ", intro=" + intro
				+ ", level=" + level + ", picture=" + picture + ", saleNum=" + saleNum + "]";
	}
}
