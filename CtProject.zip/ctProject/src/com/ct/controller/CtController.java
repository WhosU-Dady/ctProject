package com.ct.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.net.URLDecoder;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.ct.service.*;
import com.ct.pojo.*;

@Controller
public class CtController extends HttpServlet{
	
	@Autowired
	UserService userservice;	
	@Autowired
	MenuInfoService menuInfoService;
	@Autowired
	AccountService accountService;
	@Autowired
	ShoppingService shoppingService;
	@Autowired
	FavouriteService favouriteService;
	@Autowired
	ChatService chatService;
	@Autowired
	MenuCommentService menuCommentService;
	
	
	//nian 
	@RequestMapping("/error")
	public String error() {
		return "error";
	}
	
	@RequestMapping("/toLogin")
	public String toLogin() {
//		System.out.println(userservice.selectUserInfo());
		return "nian/Login";
	}
	@RequestMapping("/reLogin")
	public String reLogin(Model model,String userName) {
		model.addAttribute("userName",userName);
//		System.out.println(userservice.selectUserInfo());
		return "nian/Login";
	}

	
	//登录
	@RequestMapping("/toIndex")
	public String login(User user,HttpSession session,Model model) {
		String userName = user.getUserName();
//		System.out.println(userName);
		User queryUserByUserName = userservice.queryUserByUserName(userName);
//		System.out.println(queryUserByUserName);
		try {
			if(queryUserByUserName.getPassword().equals(user.getPassword())) {
				session.setAttribute("user", queryUserByUserName);
				session.setAttribute("userName", userName);
				model.addAttribute("msg","登录成功");
				//查询菜品
				model.addAttribute("MenuInfos",menuInfoService.selectMenuInfo());
				model.addAttribute("tips","登录成功！");
				if(userName.equals("root")) {
					return "zzc/menuInfo";
				}else {
					return "zzc/UserMenuInfo";
				}

				
			}else{
				model.addAttribute("tips","账号或密码错误！");
				System.out.println("登录失败，请重新输入！");
			}
		}catch(Exception ex) {
			model.addAttribute("tips","账号或密码错误！");
			System.out.println("登录失败，请重新输入！");
		}
		return "nian/Login";
		
	}	
		
	@RequestMapping("/toRegister")
	public String toRegister() {
		return "nian/Register";	
	}
	
	@RequestMapping("/toForgetPassword")
	public String toForgetPassword() {
		return "nian/ForgetPassword";	
	}
	//查询所有用户信息
	@RequestMapping("/toManagerUser")
	public String toselectUser(User user,Model model) {
		model.addAttribute("users", userservice.selectUserInfo());
//		System.out.println("111");
		return "nian/ManagerUser";	
	}
	//注册验证用户唯一性
	@RequestMapping("/testRegister")
	public String testregister(User user,Model model,Account accout) {
		
		try {
			if(userservice.insertUserInfo(user)>0) {
				model.addAttribute("tips", "注册成功！");
				
				return "nian/Login";		
			}
		}catch(Exception ex){
			model.addAttribute("tips", "注册失败，用户名已被注册！");
//			System.out.println("用户注册失败，用户名重复！");
		}
		return "nian/Register";
	}
	//验证用户修改密码问题
	@RequestMapping("/testForgetPassword")
	public String testForgetPassword(User user) {
		User queryUserByUserName = userservice.queryUserByUserName(user.getUserName());
		if(queryUserByUserName.getEmail().equals(user.getEmail()) && queryUserByUserName.getSecQuestion().equals(user.getSecQuestion()) && queryUserByUserName.getSecAnswer().equals(user.getSecAnswer())) {
			userservice.updatePwd(user.getPassword(), queryUserByUserName.getUserName());
			return "nian/Login";
		}
		return "nian/Finderror";
	}

	//删除用户
	@RequestMapping("/deleteByUserName")
	public String deleteByUserName(String userName,Model model) {
		userservice.deleteUserInfo(userName);
		model.addAttribute("users", userservice.selectUserInfo());
//		System.out.println("w dao le ");
		return "nian/ManagerUser";	
	}
	
	//管理员查找用户
	@RequestMapping("/selectUser")
	public String selectUser(User user,HttpSession session,Model model) {
		String userName = user.getUserName();
		User queryUserByUserName = userservice.queryUserByUserName(userName);

		return "nian/ManagerUser";
	}
	
	
	
	
	
	
	
	//zzc
	//查询所有菜品信息
	@RequestMapping("/tomenuInfo")
	public String tomenuInfo(MenuInfo menuInfo,Model model,String userName) {
		model.addAttribute("MenuInfos",menuInfoService.selectMenuInfo());
		model.addAttribute("userName",userName);
			return "zzc/menuInfo";

//		System.out.println("111");
//		System.out.println(userName);
		
			

	}

	

	@RequestMapping("/DeleteMenu")
	public String DeleteMenu(MenuInfo menuInfo,Model model,String userName,String menuName) {
		try {
			menuName = URLDecoder.decode(new String(Base64.getDecoder().decode(menuName)),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println(menuName);
		if(menuInfoService.deleteMenuInfo(menuName)>0) {
//			System.out.println("删除菜品成功！");
			model.addAttribute("tips","删除菜品成功！");
			model.addAttribute("MenuInfos",menuInfoService.selectMenuInfo());
				return "zzc/menuInfo";

		}else {
//			model.addAttribute("tips","删除菜品失败！");
			model.addAttribute("MenuInfos",menuInfoService.selectMenuInfo());
				return "zzc/menuInfo";
		}
		
	}
	
	
	
	@RequestMapping("/toAddFood")
	public String toAddFood() {
		return "zzc/AddFood";
	}
	
	//添加菜品，菜品唯一性
	@RequestMapping(value="/AddFood",method=RequestMethod.POST)
	public String AddFood(MenuInfo menuInfo,Model model) {
		try {
			if(menuInfoService.insertMenuInfo(menuInfo)>0) {
				model.addAttribute("tips", "添加成功！");
				return "zzc/AddFood";		
			}
		}catch(Exception ex){
			model.addAttribute("tips", "添加失败，菜品已存在！");
			System.out.println("菜品添加失败！");
		}
		return "zzc/AddFood";
	}
	
	//查询菜品
//	@RequestMapping(value="/selectmenuBymenuName",method=RequestMethod.POST)
//	public String selectmenuBymenuName(MenuInfo menuInfo,HttpSession session,Model model) {
//		String menuInfoName = menuInfo.getMenuName();
//		System.out.println(menuInfoName);
//		System.out.println(menuInfoService.queryMenuInfoBymenuName(menuInfoName));
//		model.addAttribute("MenuInfos",menuInfoService.queryMenuInfoBymenuName(menuInfoName));
//		return "zzc/menuInfo";
//	}
	
	
	
	//ywx
	//充值
	@RequestMapping("/rechargeDo")
	public String rechargeDo(Model model,Account account,int money,String userName) {
		model.addAttribute("tips", "");
		try {
			if(accountService.updateAccountMoney(money, userName)>0) {
				model.addAttribute("tips","充值成功！");
				return "ywx/Recharge";
			
			}else{
				
				model.addAttribute("tips","充值失败，请确认用户是否存在！");
				System.out.println("充值失败！");
			}
		}catch(Exception ex){
//			System.out.println(ex);
		}
		return "ywx/Recharge";

	}
	
	@RequestMapping(value="/torecharge")
	public String torecharge() {
		return "ywx/Recharge";
	}	
	//根据菜名查询菜品信息
	@RequestMapping(value="/toMenu")
	public String toMenu(String menuName, Model model) {
//		String menuName=session.getAttribute("userid");
		try {
			menuName = URLDecoder.decode(new String(Base64.getDecoder().decode(menuName)),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(menuCommentService.queryCommentByMenuName(menuName));
		System.out.println("11111");
		model.addAttribute("MenuComment",menuCommentService.queryCommentByMenuName(menuName));
		model.addAttribute("menu",menuInfoService.queryMenuInfoBymenuName(menuName));
		System.out.println(menuInfoService.queryMenuInfoBymenuName(menuName));
		return "zzc/Menu";
	}		
	
	
	@RequestMapping(value="/toMenuList")
	public String toMenuList(String menuName,Model model) {
		return "ywx/MenuList";
	}	
	
	//购物清单

	@RequestMapping(value="/MenuList",method=RequestMethod.POST)
	public String MenuList(Model model,Shopping shopping,String userName,int shoppingSum,String menuName) {
		System.out.println(userName);
		System.out.println(shoppingSum);
		try {
			if(accountService.queryAccountByUserName(userName).getMoney()>=shoppingSum && shoppingService.insertShopping(shopping)>0) {
				accountService.AccountComsume(shoppingSum, userName);
//				System.out.println("结账成功！");
				model.addAttribute("tips", "结账成功");
				model.addAttribute("MenuInfos",menuInfoService.selectMenuInfo());
				if(userName.equals("root")) {
					return "zzc/menuInfo";
				}else {
					return "zzc/UserMenuInfo";
				}

				
				
			}else {
				System.out.println("结账失败！");
				model.addAttribute("tips", "结账失败");
				model.addAttribute("MenuInfos",menuInfoService.selectMenuInfo());
				if(userName.equals("root")) {
					return "zzc/menuInfo";
				}else {
					return "zzc/UserMenuInfo";
				}
			}
		}catch(Exception e) {
			model.addAttribute("tips", "结账失败");
			System.out.println("结账失败");
			model.addAttribute("MenuInfos",menuInfoService.selectMenuInfo());
			if(userName.equals("root")) {
				return "zzc/menuInfo";
			}else {
				return "zzc/UserMenuInfo";
			}
		}
	}
	
	
	
	
	//csg
	
	@RequestMapping(value="/toUserSpace")
	public String toUserSpace(String userName,Model model,User user,String menuName) {
		
		model.addAttribute("restMoney",accountService.queryAccountByUserName(userName).getMoney());
		model.addAttribute("userInfo",userservice.queryUserByUserName(userName));
//		System.out.println(userservice.queryUserByUserName(userName));
//		!!
		model.addAttribute("Shopping",shoppingService.selectShopping(userName));
//		System.out.println(shoppingService.selectShopping(userName));
		model.addAttribute("favourites",favouriteService.selectFavourite(userName));
//		System.out.println(favouriteService.selectFavourite(userName));
		List<Shopping> Slist = shoppingService.selectShopping(userName);
		List<String> plist = new ArrayList<String>();
		List<String> dlist = new ArrayList<String>();
		for (Shopping p : Slist) {
			plist.add(String.valueOf(p.getShoppingSum()));
		}
		for (Shopping d : Slist) {
			dlist.add(d.getShoppingDate());
		}		
		//获取date和price的list
		model.addAttribute("plists", plist);
		model.addAttribute("dlists", dlist);
		
		return "csg/UserSpace";
	}	
	@RequestMapping(value="/AddFavourite")
	public String AddFavourite(Model model,String userName,String menuName) {
		try {
			menuName = URLDecoder.decode(new String(Base64.getDecoder().decode(menuName)),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		System.out.println(userName);
//		System.out.println(menuName);
//		System.out.println(menuInfoService.selectMenuInfo());
		try {
			if(favouriteService.insertFavourite(userName, menuName)>0) {
				model.addAttribute("MenuInfos", menuInfoService.selectMenuInfo());
				model.addAttribute("tips", "菜品添加收藏成功！");
				if(userName.equals("root")) {
					return "zzc/menuInfo";
				}else {
					return "zzc/UserMenuInfo";
				}
			}
		}catch(Exception ex) {
			
		}
		return "zzc/Menu";
	}	
	

	@RequestMapping(value="/toManager")
	public String toChatOnly() {
		return "manager/manage";
	}

	
	
	//ych
	
	@RequestMapping(value="chatDo",method=RequestMethod.POST)
	public String save(Chat chat,Model model) {
		if(chatService.insert(chat)>0) {
			model.addAttribute("chats", chatService.selectAll());
			return "ych/ChatAll";
			
		}else {
			model.addAttribute("msg", "服务器异常：新增聊天信息失败");
			System.out.println(chatService.selectAll());
			return "ych/ChatAdd";
		}
	}
	@RequestMapping(value="/chatAll")
	public String toChatAll(Model model) {
		model.addAttribute("chats", chatService.selectAll());
		return "ych/ChatAll";
	}

	@RequestMapping(value="/chatAdd")
	public String toChatAdd() {
		return "ych/ChatAdd";
	}
	
	@RequestMapping(value="/chatOnlyDo")
	public String ChatOnly(Chat chat,Model model) {
//		System.out.println(chat.getContent());
		model.addAttribute("chatsO", chatService.selectAll());
		return "ych/ChatOnly";
	}
	
	@RequestMapping(value="/chatOnly")
	public String toChatOnly(Model model) {
		model.addAttribute("chatsO", chatService.selectAll());
		return "ych/ChatOnly";
	}
	
	//评论菜品
	@RequestMapping(value="/AddComment")
	public String AddComment(Model model,String userName,String menuName,String commentContent) {
		try {
			menuName = URLDecoder.decode(new String(Base64.getDecoder().decode(menuName)),"UTF-8");
			commentContent = URLDecoder.decode(new String(Base64.getDecoder().decode(commentContent)),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(userName);
		System.out.println(menuName);
		System.out.println(commentContent);
		
		try {
			if(menuCommentService.insertMenuComment(userName,menuName,commentContent)>0) {
				model.addAttribute("MenuInfos",menuInfoService.selectMenuInfo());
//				System.out.println(menuCommentService.queryUserByMenuName(menuName));
				model.addAttribute("tips", "评论成功！");
				if(userName.equals("root")) {
					return "zzc/menuInfo";
				}else {
					return "zzc/UserMenuInfo";
				}
			}
		}catch(Exception ex){
			model.addAttribute("tips", "评论失败，请检查是否登录！");
		}
		if(userName.equals("root")) {
			return "zzc/menuInfo";
		}else {
			return "zzc/UserMenuInfo";
		}
	}
	
	
	
//	try {
//		menuName = URLDecoder.decode(new String(Base64.getDecoder().decode(menuName)),"UTF-8");
//	} catch (UnsupportedEncodingException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
}

