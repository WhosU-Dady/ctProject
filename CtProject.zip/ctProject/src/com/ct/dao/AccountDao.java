package com.ct.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ct.pojo.Account;

public interface AccountDao {
	//增加
	@Insert("insert into Accountinfo (userName,money) values(#{userName},#{money})")
	public int insertAccount(Account account);
	
	//充值
	@Update("update Accountinfo set money=#{money}+money where userName = #{userName}")
	public int updateAccountMoney(@Param("money")int money,@Param("userName")String userName);
	
	//消费
	@Update("update Accountinfo set money=money-#{shoppingSum} where userName = #{userName}")
	public int AccountComsume(@Param("shoppingSum")int shoppingSum,@Param("userName")String userName);

	//根据用户名查询用户信息（管理员根据用户名查询用户、登录）1
	@Select("select * from Accountinfo where userName=#{userName}")
	@ResultType(Account.class)
	public Account queryAccountByUserName(String userName);		
}
