package com.ct.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ct.pojo.MenuInfo;;

public interface MenuDao {
	//菜品增加
	@Insert("insert into menuinfo (menuName,price,menuType,intro,level,picture,saleNum) values(#{menuName},#{price},#{menuType},#{intro},#{level},#{picture},#{saleNum})")
	public int insertMenuInfo(MenuInfo menuInfo);	
	
	//根据菜名删除菜品
	@Delete("delete from MenuInfo where menuName=#{menuName}")
	public int deleteMenuInfo(String menuName);
	
	//根据字符查询菜品
	@Select("select * from MenuInfo where menuName=#{menuName}")
	@ResultType(MenuInfo.class)
	public MenuInfo queryMenuInfoBymenuName(String menuName);
	
	//查询所有菜品
	@Select("select * from MenuInfo")
	@ResultType(MenuInfo.class)
	public List<MenuInfo> selectMenuInfo();

//	//菜品销量更新
//	@Update("update MenuInfo set saleNum=saleNum+1 where userName = #{userName}")
//	public int updateMenuInfosaleNum(String userName);
	

}
