package com.ct.dao;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import com.ct.pojo.Chat;

public interface ChatDao {
	//加入聊天信息
	@Insert("insert into Chat(sender,acceptor,date,content) values(#{sender},#{acceptor},#{date},#{content})")
	public int insert(Chat chat);
	
	//查询聊天信息
	@Select("Select * from Chat")
	@ResultType(Chat.class)
	public List<Chat> selectAll();

}
