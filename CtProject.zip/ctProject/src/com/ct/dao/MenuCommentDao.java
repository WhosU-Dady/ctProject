package com.ct.dao;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import com.ct.pojo.MenuComment;

public interface MenuCommentDao {
	//插入
	@Insert("insert into MenuComment (userName,menuName,commentContent) values(#{userName},#{menuName},#{commentContent})")
	public int insertMenuComment(@Param("userName")String userName,@Param("menuName")String menuName,@Param("commentContent")String commentContent);
	
	//根据菜名查询评论
	@Select("select * from MenuComment where menuName=#{menuName}")
	@ResultType(MenuComment.class)
	public List<MenuComment> queryCommentByMenuName(String menuName);
	
	//查询所有评论
	@Select("select * from MenuComment")
	@ResultType(MenuComment.class)
	public List<MenuComment> selectMenuComment();

}
