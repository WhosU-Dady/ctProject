package com.ct.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;

import com.ct.pojo.Favourite;;

public interface FavouriteDao {
	//加入收藏夹
	@Insert("insert into Favourite (userName,menuName) values(#{userName},#{menuName})")
	public int insertFavourite(@Param("userName")String userName,@Param("menuName")String menuName);
	
	//根据菜名删除菜品
	@Delete("delete from Favourite where menuName=#{menuName}")
	public int deleteFavourite(String menuName);
	
	//查询所有收藏菜品
	@Select("select * from Favourite where userName=#{userName}")
	@ResultType(Favourite.class)
	public List<Favourite> selectFavourite(String userName);
	
}
