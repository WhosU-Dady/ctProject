package com.ct.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ct.pojo.User;

public interface UserDao {
	//插入（注册）1
	@Insert("insert into userinfo (userName,password,email,secQuestion,secAnswer) values(#{userName},#{password},#{email},#{secQuestion},#{secAnswer})")
	public int insertUserInfo(User user);
	
	//根据用户名删除（管理用户）0
	@Delete("delete from userinfo where userName=#{userName}")
	public int deleteUserInfo(String userName);
	
	//修改密码（忘记密码）1
	@Update("update userinfo set password=#{password} where userName = #{userName}")
	public int updateUserInfo(@Param("password")String password,@Param("userName")String userName);
	
	//根据用户名查询用户信息（管理员根据用户名查询用户、登录）1
	@Select("select * from userinfo where userName=#{userName}")
	@ResultType(User.class)
	public User queryUserByUserName(String userName);
	
	//查询所有用户（管理员查看所有用户）0
	@Select("select * from userinfo")
	@ResultType(User.class)
	public List<User> selectUserInfo();
	
}
