package com.ct.dao;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ct.pojo.Shopping;

public interface ShoppingDao {
	//插入
	@Insert("insert into Shopping (userName,Menus,shoppingSum) values(#{userName},#{menus},#{shoppingSum})")
	public int insertShopping(Shopping shopping);
	
	//查询所有订单信息
	@Select("select * from Shopping")
	@ResultType(Shopping.class)
	public List<Shopping> queryShopping();
	
	//用户消费更新
//	@Update("update Shopping set userComsume=#{shoppingSum}+userComsume where userName = #{userName}")
//	public int updateShoppinguserComsume(@Param("shoppingSum")int shoppingSum,@Param("userName")String userName);

	
	//根据用户名查询订单信息
	@Select("select * from Shopping where userName=#{userName}")
	@ResultType(Shopping.class)
	public List<Shopping> selectShopping(String userName);
	
}
