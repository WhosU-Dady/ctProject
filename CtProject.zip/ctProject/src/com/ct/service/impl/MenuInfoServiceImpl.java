package com.ct.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.pojo.MenuInfo;
import com.ct.service.MenuInfoService;
import com.ct.dao.MenuDao;

@Service
public class MenuInfoServiceImpl implements MenuInfoService{

	@Autowired
	MenuDao menudao;

	
	@Override
	public int insertMenuInfo(MenuInfo menuInfo) {
		// TODO Auto-generated method stub
		return menudao.insertMenuInfo(menuInfo);
	}

	@Override
	public int deleteMenuInfo(String menuName) {
		// TODO Auto-generated method stub
		return menudao.deleteMenuInfo(menuName);
	}

	@Override
	public MenuInfo queryMenuInfoBymenuName(String menuName) {
		// TODO Auto-generated method stub
		return menudao.queryMenuInfoBymenuName(menuName);
	}

	@Override
	public List<MenuInfo> selectMenuInfo() {
		// TODO Auto-generated method stub
		return menudao.selectMenuInfo();
	}

}
