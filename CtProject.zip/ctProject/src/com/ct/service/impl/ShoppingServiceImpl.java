package com.ct.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.ShoppingDao;
import com.ct.pojo.Shopping;
import com.ct.service.ShoppingService;
@Service
public class ShoppingServiceImpl implements ShoppingService{

	@Autowired
	ShoppingDao shoppingdao;
	@Override
	public int insertShopping(Shopping shopping) {
		return shoppingdao.insertShopping(shopping);
		
	}

	@Override
	public List<Shopping> queryShopping() {
		return shoppingdao.queryShopping();

	}

	@Override
	public List<Shopping> selectShopping(String userName) {
		return shoppingdao.selectShopping(userName);

	}

//	@Override
//	public int updateShoppinguserComsume(int shoppingSum, String userName) {
//		// TODO Auto-generated method stub
//		return shoppingdao.updateShoppinguserComsume(shoppingSum, userName);
//	}

}
