package com.ct.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.ChatDao;
import com.ct.pojo.Chat;
import com.ct.service.ChatService;
@Service
public class ChatServiceImpl implements ChatService{
	@Autowired
	ChatDao chatDao;
	
	@Override
	public int insert(Chat chat) {
		return chatDao.insert(chat);
	}

	@Override
	public List<Chat> selectAll() {
		// TODO Auto-generated method stub
		return chatDao.selectAll();
	}
}
