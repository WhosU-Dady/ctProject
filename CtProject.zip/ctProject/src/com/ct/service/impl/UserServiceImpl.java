package com.ct.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.UserDao;
import com.ct.pojo.User;
import com.ct.service.UserService;
@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao userdao;

	@Override
	public int insertUserInfo(User user) {
		return userdao.insertUserInfo(user);
	}

	@Override
	public int updatePwd(String password,String userName) {
		return userdao.updateUserInfo(password,userName);
	}

	@Override
	public User queryUserByUserName(String userName) {
		return userdao.queryUserByUserName(userName);
	}
	
	@Override
	public int deleteUserInfo(String userName) {
		// TODO Auto-generated method stub
		return userdao.deleteUserInfo(userName);
	}

	@Override
	public List<User> selectUserInfo() {
		// TODO Auto-generated method stub
		return userdao.selectUserInfo();
	}

}
