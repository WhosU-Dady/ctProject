package com.ct.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.FavouriteDao;
import com.ct.pojo.Favourite;
import com.ct.service.FavouriteService;

@Service
public class FavouriteServiceImpl implements FavouriteService{

	@Autowired
	FavouriteDao favouritedao;	
	@Override
	public int insertFavourite(String userName,String menuName) {
		// TODO Auto-generated method stub
		return favouritedao.insertFavourite(userName,menuName);
	}

	@Override
	public int deleteFavourite(String menuName) {
		// TODO Auto-generated method stub
		return favouritedao.deleteFavourite(menuName);
	}

	@Override
	public List<Favourite> selectFavourite(String userName) {
		// TODO Auto-generated method stub
		return favouritedao.selectFavourite(userName);
	}

}
