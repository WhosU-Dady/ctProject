package com.ct.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.MenuCommentDao;
import com.ct.service.MenuCommentService;
import com.ct.pojo.MenuComment;
@Service
public class MenuCommentServiceImpl implements MenuCommentService{
	
	@Autowired
	MenuCommentDao menuCommentDao;
	
	@Override
	public int insertMenuComment(String userName,String menuName,String commentContent) {
		
		return menuCommentDao.insertMenuComment(userName,menuName,commentContent);
	}

	@Override
	public List<MenuComment> queryCommentByMenuName(String menuName) {
		// TODO Auto-generated method stub
		return menuCommentDao.queryCommentByMenuName(menuName);
	}

	@Override
	public List<MenuComment> selectMenuComment() {
		// TODO Auto-generated method stub
		return menuCommentDao.selectMenuComment();
	}



}
