package com.ct.service.impl;

import com.ct.service.AccountService;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.AccountDao;
import com.ct.pojo.Account;

@Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	AccountDao accountdao;
	
	@Override
	public int insertAccount(Account account) {
		// TODO Auto-generated method stub
		return accountdao.insertAccount(account);
	}

	@Override
	public int updateAccountMoney(int money, String userName) {
		// TODO Auto-generated method stub
		return accountdao.updateAccountMoney(money,userName);
	}

	@Override
	public Account queryAccountByUserName(String userName) {
		// TODO Auto-generated method stub
		return accountdao.queryAccountByUserName(userName);
	}

	@Override
	public int AccountComsume(int shoppingSum,String userName) {
		// TODO Auto-generated method stub
		return accountdao.AccountComsume(shoppingSum,userName);
	}


}
