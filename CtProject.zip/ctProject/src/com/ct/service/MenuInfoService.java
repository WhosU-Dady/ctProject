package com.ct.service;

import java.util.List;

import com.ct.pojo.MenuInfo;

public interface MenuInfoService {
	public int insertMenuInfo(MenuInfo menuInfo);
	public int deleteMenuInfo(String menuName);
	public MenuInfo queryMenuInfoBymenuName(String menuName);
	public List<MenuInfo> selectMenuInfo();
}
