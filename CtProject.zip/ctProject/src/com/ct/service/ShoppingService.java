package com.ct.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ct.pojo.Shopping;

public interface ShoppingService {
	public int insertShopping(Shopping shopping);
	public List<Shopping> queryShopping();
	public List<Shopping> selectShopping(String userName);
//	public int updateShoppinguserComsume(@Param("shoppingSum")int shoppingSum,@Param("userName")String userName);
	
}
