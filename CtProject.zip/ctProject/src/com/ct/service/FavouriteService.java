package com.ct.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ct.pojo.Favourite;

public interface FavouriteService {
	public int insertFavourite(@Param("userName")String userName,@Param("menuName")String menuName);
	public int deleteFavourite(String menuName);
	public List<Favourite> selectFavourite(String userName);
}
