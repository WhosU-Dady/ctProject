package com.ct.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ct.pojo.Account;;

public interface AccountService {
	public int insertAccount(Account account);
	public int updateAccountMoney(@Param("money")int money,@Param("userName")String userName);
	public Account queryAccountByUserName(String userName);
	public int AccountComsume(@Param("shoppingSum")int shoppingSum,@Param("userName")String userName);
}
