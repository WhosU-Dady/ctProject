package com.ct.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ct.pojo.User;

public interface UserService {
	public int insertUserInfo(User user);
	public int updatePwd(@Param("password")String password,@Param("userName")String userName);
	public User queryUserByUserName(String userName);
	public List<User> selectUserInfo();
	public int deleteUserInfo(String userName);
	
}
