package com.ct.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ct.pojo.MenuComment;

public interface MenuCommentService {
	public int insertMenuComment(@Param("userName")String userName,@Param("menuName")String menuName,@Param("commentContent")String commentContent);
	public List<MenuComment> queryCommentByMenuName(String menuName);
	public List<MenuComment> selectMenuComment();

}
