package com.ct.service;

import java.util.List;

import com.ct.pojo.Chat;

public interface ChatService {
	public int insert(Chat chat);
	
	public List<Chat> selectAll();
}
